#include <atmel_start.h>
#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"
#include "helper.h"
#include <stdbool.h>
#include <hal_atomic.h>

//
#define COMPARE_CHANNEL_0 0
#define ADC0_CHANNEL 0
#define ADC1_CHANNEL 0
#define CURRENT_MES_FLAG 0
#define TORQUE_OFFSET 1.65 //in Volt //measure this value with voltmeter when no force is applied and set it in macro Default is VDD/2
#define TORQUE_REF 3.3 // in Volt torque reference voltage
#define G_AMP 561 //scalar
#define G_SENS 0.5 // mV/V
//QSPI_Definitions
uint16_t addr_AbortFIFO = 0x430C;
uint32_t AbortFIFO[3] = {0x40000000, 0x00000000, 0x40000000};
uint16_t addr_ClearRdRAM_1 = 0x0020;
uint32_t ClearRdRAM_1[16] =	  { 0, 0, 0, 0,		 0, 0, 0, 0,
								0, 0, 0, 0,		 0, 0, 0, 0};
uint16_t addr_ClearRdRAM_2 = 0x4310;
uint32_t ClearRdRAM_2[2] =  {0x00401000, 0x80000000};
uint16_t addr_ConfigFIFO = 0x4308;
uint32_t ConfigFIFO[4] =  { 0x00401000, 0x80000000, 0x00401800, 0x80000000};
uint16_t addr_WriteFIFO = 0x0020;
uint32_t cnt = 0;
float WriteFIFO[16] = {0, 1, (1<<1), (1<<2), (1<<3), (1<<4), (1<<5), (1<<6), (1<<7),
(1<<8), (1<<10), (1<<15), (1<<16), (1<<21), (1<<26), (1<<31)};
uint16_t addr_ReadFIFO = 0x0000;
uint32_t ReadFIFO[16] = {};
//ADC_definitions
uint16_t buffA, buffB, buffC;
float currA, currB, voltA, voltB;
float curr_reference = 0;
float V_in_ADC, V_sens, trq_in_N;

//CCL definitions
volatile uint32_t H_0_pulse_width;
float rot_speed = 0;
float H_0_pulse_width_in_sec;

//PWM and Speed calc
uint8_t hall = 0;
uint8_t steps[8] = {0,5,3,4,1,0,2,0};
uint16_t patterns[16] = {0x00FF, 0x10D2, 0x40E4, 0x40D2, 0x2036, 0x1036, 0x20E4, 0x00FF, 0x00FF, 0x20E4, 0x1036, 0x2036, 0x40D2, 0x40E4, 0x10D2, 0x00FF};
uint8_t step[2] = {0};
int32_t revolution_counter_elec = 0;
float revolution_counter_mech = 0;
float rel_position = 0;


//----CONTROL_VARIABLES--------
volatile float out_i[4]={0};
volatile float out_w[4]={0};
volatile float out_p[4]={0};
volatile bool current_ready, trq_ready = {true, true};
float desired_pos = 0;
float desired_trq = 0;
float desired_spd = 0;
float desired_curr = 0;
float kp_p = 0; //position prop gain
float kp_n = 0; //speed prop gain
float joint_max_speed = 0;
float v_max = 24; //max voltage
float i_max = 0.3; //max current
float w_max = 700; //max current
float kp_i = 0; //curr prop gain
float ki_i = 0; //curr int gain

float kt = 0.0322; //  Nm/A
uint8_t direction = 0;
uint8_t activate_control = 1;
uint8_t control_type = 0; //0 curr, 1 speed, 2 pos

float volt_ref = 0;
float curr_ref_controller = 0;
float speed_ref_controller = 0;

//----for encoder
extern uint8_t encoder_raw_data[6];
extern uint16_t encoder_multiturn_counter;
extern float encoder_position;
extern float encoder_position_in_rad;
extern float encoder_offset;
extern uint8_t encoder_Err;
extern uint8_t encoder_Not_Warning ;
extern uint8_t encoder_crc_inv;


///Interrupt Handlers
void ADC0_1_Handler(){ //ADC0_RESRDY
	ADC0->INTFLAG.bit.RESRDY=1;
		if(!current_ready || !trq_ready){
			if (ADC0->INPUTCTRL.bit.MUXPOS == 0) {
				buffA= ADC0->RESULT.reg;
				buffB= ADC1->RESULT.reg;

				voltA= (buffA/4095.0) * 3300; //Define the conversion ratio of your ADC value to a float representing the current
				voltB= (buffB/4095.0) * 3330;
	
				currA=(voltA-1500)/200;
				currB=(voltB-1500)/200;
				current_ready = true;
				ADC0->INPUTCTRL.bit.MUXPOS = 1; //Change channel to 1 for torque read
				ADC0->SWTRIG.bit.START = 1; //Start conversion manually, cleared automatically in HW
			}
			else if (ADC0->INPUTCTRL.bit.MUXPOS == 1) {
				buffC= ADC0->RESULT.reg; //Read out trq
				V_in_ADC = (buffA*TORQUE_REF)/4095;
				V_sens = (V_in_ADC - TORQUE_OFFSET)/G_AMP;
				trq_in_N = V_sens / (G_SENS*TORQUE_REF);
				trq_ready = true;
				ADC0->INPUTCTRL.bit.MUXPOS = 0; //Change channel to 0 for following current read
			}
		}
}



void TC0_Handler(void)
{
	if(TC0->COUNT32.INTFLAG.bit.OVF){ // if overflow happened
		TC0->COUNT32.INTFLAG.bit.OVF = 1;
		rot_speed = 0x0;
	}
	else if  (TC0->COUNT32.INTFLAG.bit.ERR){
		TC0->COUNT32.INTFLAG.bit.ERR = 1;
		rot_speed = 0xFFFFFFFF;
	}
	else{
		TC0->COUNT32.INTFLAG.bit.MC0 = 1;
		H_0_pulse_width = TC0->COUNT32.CC[0].reg;
		H_0_pulse_width_in_sec = H_0_pulse_width * (float) 0.00000001; // 100 Mhz
		rot_speed = (3.1415 / 3.0 / 7) / H_0_pulse_width_in_sec; // omega = (60° / 7 / delta_t)  - 7 because of pole pairs of the motor
	}
	
}

void set_motor_voltage(uint8_t hall)
{
/////
	TCC0->PATTBUF.reg = patterns[hall];
	//hri_tcc_write_CTRLA_ENABLE_bit(TCC0, 1 << TCC_CTRLA_ENABLE_Pos); /* Enable: enabled */

		}

void get_position(uint8_t hall)
{
	step[0] = steps[hall]; //update position

	if (step[0] == 5 && step[1] == 0)
	revolution_counter_elec++;
	else if (step[0] == 0 && step[1] == 5)
	revolution_counter_elec--;

	rel_position = revolution_counter_elec*5 + step[1];
	revolution_counter_mech = rel_position / 42;

	step[1] = step[0];  //step[1] = previous position, step[0] - latest position
}





int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	custom_logic_init();
	custom_logic_enable();
	qspi_sync_enable(&ECAT_QSPI);
	adc_sync_enable_channel(&CURR_A_TRQ_ADC, 0);
	adc_sync_enable_channel(&CURR_B_ADC, 0);
	QUAD_SPI_0_write(addr_AbortFIFO, AbortFIFO, sizeof(AbortFIFO));
	QUAD_SPI_0_write(addr_ClearRdRAM_1, ClearRdRAM_1, sizeof(ClearRdRAM_1));
	QUAD_SPI_0_write(addr_ClearRdRAM_2, ClearRdRAM_2, sizeof(ClearRdRAM_2));
		
	NVIC_EnableIRQ(TC0_IRQn);
	NVIC_EnableIRQ(ADC0_1_IRQn);
	ADC0->INTENSET.bit.RESRDY = 1; //Reset the RESRDY Interrupt
		
	gpio_set_pin_level(ENC_CS, 1); //setup CS SPI_Encoder
	ENC_SPI_init();
	ENC_SPI_enable();
	set_encoder_offset_zero();

	uint32_t hallA, hallB, hallC;
		while (1) {
			receive_data_from_encoder();
			// 		kp_i = ;
			// 		ki_i = ;
			// 		desired_curr = ;
			// 		desired_spd = *desired_speed;
			// 		desired_pos = *desired_position;
			// 		desired_trq = *desired_torque;
			// 		kp_n = *tau_kd;
			// 		kp_p = *tau_kp;
			// 		i_max = *I_max;
			// 		w_max = *Joint_max_speed;
			// 		activate_control = *control_mode;
			// 		control_type = *control_set;
			
			if(activate_control){
				
				if (current_ready && trq_ready){
					
					current_ready = false;
					trq_ready = false;
					hall = 0;
					hallA = gpio_get_pin_level(Hall_A);
					hallB = gpio_get_pin_level(Hall_B);
					hallC = gpio_get_pin_level(Hall_C);

					hall = (hallA<<2)|(hallB<<1)|hallC;

					switch(hall) {
						case 1:
						curr_reference = -currA;
						break;
						case 2:
						curr_reference = -currB;
						break;
						case 3:
						curr_reference = -currA;
						break;
						case 4:
						curr_reference = currB;
						break;
						case 5:
						curr_reference = currB;
						break;
						case 6:
						curr_reference = -currA;
						break;
					}
					
					get_position(hall);
					
					if(control_type == 1){ //speed control
						p_controller(out_w, desired_spd, rot_speed, kp_n, i_max*kt); // max current = 0.3
						curr_ref_controller =  out_w[0] / kt;
						pi_controller(out_i, curr_ref_controller, curr_reference, kp_i, ki_i, v_max); //max voltage = 24
					}
					else if (control_type == 2){ //position control
						p_controller(out_p, desired_pos, rel_position, kp_p, w_max); //max speed = 700
						p_controller(out_w, out_p[0], rot_speed, kp_n, i_max*kt); // max current = 0.3
						curr_ref_controller =  out_w[0] / kt;
						pi_controller(out_i, curr_ref_controller, curr_reference, kp_i, ki_i, v_max); //max voltage = 24
					}
					else{ //current control
						pi_controller(out_i, desired_curr, curr_reference, kp_i, ki_i, v_max); //max voltage = 24
					}
					
					volt_ref = (out_i[0] + kt*rot_speed) * 2000 / 24; //Feed-forward
					direction = (volt_ref <0);
					
					hall = hall | (direction <<3);
					
					set_motor_voltage(hall);
					TCC0->CCBUF->reg = 0; /* Channel 0 Compare/Capture Value: 0x0 */
					

					// 				if(volt_ref > 0){
					// 					TCC0->CCBUF->reg = volt_ref;
					// 				}
					// 				else{
					// 					TCC0->CCBUF->reg = -volt_ref;
					// 				}
					
					// 				*read_position = step[1];
					// 				*read_rel_position = rel_position;
					// 				*read_current_i_q = currA_in_Amp;
					// 				*read_current_i_d = CurrB_in_Amp;
					// 				*read_current_i_m = curr_reference;
					// 				*read_speed = rot_speed;
				}
			}
			else{ //control deactivated
				TCC0->CCBUF->reg = 0; //turn off pwm
			}
			
			
		}			//end while
	}				//end main

