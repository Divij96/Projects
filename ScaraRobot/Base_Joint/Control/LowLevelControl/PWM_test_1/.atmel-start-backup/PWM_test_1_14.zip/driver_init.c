/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>

void PWM_0_PORT_init(void)
{

	gpio_set_pin_function(PA21, PINMUX_PA21G_TCC0_WO1);

	gpio_set_pin_function(PA22, PINMUX_PA22G_TCC0_WO2);

	gpio_set_pin_function(PA16, PINMUX_PA16G_TCC0_WO4);

	gpio_set_pin_function(PA17, PINMUX_PA17G_TCC0_WO5);

	gpio_set_pin_function(PA18, PINMUX_PA18G_TCC0_WO6);

	gpio_set_pin_function(PA19, PINMUX_PA19G_TCC0_WO7);
}

void PWM_0_CLOCK_init(void)
{
	hri_mclk_set_APBBMASK_TCC0_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, TCC0_GCLK_ID, CONF_GCLK_TCC0_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
}

void system_init(void)
{
	init_mcu();

	PWM_0_CLOCK_init();

	PWM_0_PORT_init();

	PWM_0_init();
}
