#include <atmel_start.h>
#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"



//
#define COMPARE_CHANNEL_0 0
#define ADC0_CHANNEL 0
#define ADC1_CHANNEL 0
#define CURRENT_MES_FLAG 0
#define TORQUE_OFFSET 1.65 //in Volt //measure this value with voltmeter when no force is applied and set it in macro Default is VDD/2
//QSPI_Definitions
uint16_t addr_AbortFIFO = 0x430C;
uint32_t AbortFIFO[3] = {0x40000000, 0x00000000, 0x40000000};
uint16_t addr_ClearRdRAM_1 = 0x0020;
uint32_t ClearRdRAM_1[16] =	  { 0, 0, 0, 0,		 0, 0, 0, 0,
								0, 0, 0, 0,		 0, 0, 0, 0};
uint16_t addr_ClearRdRAM_2 = 0x4310;
uint32_t ClearRdRAM_2[2] =  {0x00401000, 0x80000000};
uint16_t addr_ConfigFIFO = 0x4308;
uint32_t ConfigFIFO[4] =  { 0x00401000, 0x80000000, 0x00401800, 0x80000000};
uint16_t addr_WriteFIFO = 0x0020;
uint32_t cnt = 0;
float WriteFIFO[16] = {0, 1, (1<<1), (1<<2), (1<<3), (1<<4), (1<<5), (1<<6), (1<<7),
(1<<8), (1<<10), (1<<15), (1<<16), (1<<21), (1<<26), (1<<31)};
uint16_t addr_ReadFIFO = 0x0000;
uint32_t ReadFIFO[16] = {};
//ADC_definitions
uint16_t buffA, buffB, buffC;
float currA, currB, voltA, voltB, trqMeas;
float curr_reference = 0;


//CCL definitions
volatile uint32_t H_0_pulse_width;
float rot_speed = 0;
float H_0_pulse_width_in_sec;

//PWM and Speed calc
uint8_t hall = 0;
uint8_t steps[8] = {0,5,3,4,1,0,2,0};
uint16_t patterns[16] = {0b0000000000000000, 0x00EB, 0x00BD, 0x00BB, 0x005F, 0x006F, 0x00DD, 0x00FF, 0x00FF, 0x00DD, 0x006F, 0x005F, 0x00BB, 0x00BD, 0x00EB, 0x00FF};
uint8_t step[2] = {0};
int32_t revolution_counter_elec = 0;
float revolution_counter_mech = 0;
float rel_position = 0;


//----CONTROL_VARIABLES--------
volatile float out_i[4]={0};
volatile float out_w[4]={0};
volatile float out_p[4]={0};
volatile bool current_ready, trq_ready = {true, true};
float desired_pos = 0;
float desired_trq = 0;
float desired_spd = 0;
float desired_curr = 0;
float kp_p = 0; //position prop gain
float kp_n = 0; //speed prop gain
float joint_max_speed = 0;
float v_max = 24; //max voltage
float i_max = 0.3; //max current
float w_max = 700; //max current
float kp_i = 0; //curr prop gain
float ki_i = 0; //curr int gain

float kt = 0.0322; //  Nm/A
uint8_t direction = 0;
uint8_t activate_control = 1;
uint8_t control_type = 0; //0 curr, 1 speed, 2 pos

float volt_ref = 0;
float curr_ref_controller = 0;
float speed_ref_controller = 0;

//----for encoder
extern uint8_t encoder_raw_data[6];
extern uint16_t encoder_multiturn_counter;
extern float encoder_position;
extern float encoder_position_in_rad;
extern float encoder_offset;
extern uint8_t encoder_Err;
extern uint8_t encoder_Not_Warning ;
extern uint8_t encoder_crc_inv;


///Interrupt Handlers
void ADC0_1_Handler(){ //ADC0_RESRDY
	ADC0->INTFLAG.bit.RESRDY=1;
		if(!current_ready || !trq_ready){
			if (ADC0->INPUTCTRL.bit.MUXPOS == 0) {
				buffA= ADC0->RESULT.reg;
				buffB= ADC1->RESULT.reg;

				voltA= (buffA/4095.0) * 3300; //Define the conversion ratio of your ADC value to a float representing the current
				voltB= (buffB/4095.0) * 3300;
	
				currA=(voltA-1500)/200;
				currB=(voltB-1500)/200;
				current_ready = true;
				ADC0->INPUTCTRL.bit.MUXPOS = 1; //Change channel to 1 for torque read
				ADC0->SWTRIG.bit.START = 1; //Start conversion manually, cleared automatically in HW
			}
			else if (ADC0->INPUTCTRL.bit.MUXPOS == 1) {
				buffC= ADC0->RESULT.reg; //Read out trq
				trqMeas = (buffA/4095.0) - TORQUE_OFFSET/3.3; //measure this value with voltmeter when no force is applied and set it in macro
				trq_ready = true;
				ADC0->INPUTCTRL.bit.MUXPOS = 0; //Change channel to 0 for following current read
			}
		}
}

void TC0_Handler(void)
{
	if(TC0->COUNT32.INTFLAG.bit.OVF){ // if overflow happened
		TC0->COUNT32.INTFLAG.bit.OVF = 1;
		rot_speed = 0x0;
	}
	else if  (TC0->COUNT32.INTFLAG.bit.ERR){
		TC0->COUNT32.INTFLAG.bit.ERR = 1;
		rot_speed = 0xFFFFFFFF;
	}
	else{
		TC0->COUNT32.INTFLAG.bit.MC0 = 1;
		H_0_pulse_width = TC0->COUNT32.CC[0].reg;
		H_0_pulse_width_in_sec = H_0_pulse_width * (float) 0.00000001; // 100 Mhz
		rot_speed = (3.1415 / 3.0 / 7) / H_0_pulse_width_in_sec; // omega = (60° / 7 / delta_t)  - 7 because of pole pairs of the motor
	}
	
}

void set_motor_voltage(uint8_t hall)
{
	
	TCC0->PATTBUF.reg = patterns[hall];
	TCC0->DRVCTRL.reg = 0x00020000;
	
}

void get_position(uint8_t hall)
{
	step[0] = steps[hall]; //update position

	if (step[0] == 5 && step[1] == 0)
	revolution_counter_elec++;
	else if (step[0] == 0 && step[1] == 5)
	revolution_counter_elec--;

	rel_position = revolution_counter_elec*5 + step[1];
	revolution_counter_mech = rel_position / 42;

	step[1] = step[0];  //step[1] = previous position, step[0] - latest position
}





int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	
	uint32_t hallA, hallB, hallC;
	
	/* Replace with your application code */
// 		kp_i = ;
// 		ki_i = ;
// 		desired_curr = ;
// 		desired_spd = *desired_speed;
// 		desired_pos = *desired_position;
// 		desired_trq = *desired_torque;
// 		kp_n = *tau_kd;
// 		kp_p = *tau_kp;
// 		i_max = *I_max;
// 		w_max = *Joint_max_speed;
// 		activate_control = *control_mode;
// 		control_type = *control_set;
		
	while (1) {
		
		TCC0->CCBUF->reg = 100; //turn off pwm
		hall = hall | (direction <<3);
		
		set_motor_voltage(0);

	} //end while
}				//end main


